#!/usr/bin/sh
node --trace-warnings server/index