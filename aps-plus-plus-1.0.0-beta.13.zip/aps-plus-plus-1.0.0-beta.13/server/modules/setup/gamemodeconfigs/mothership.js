module.exports = {
    MOTHERSHIP_LOOP: true,
};