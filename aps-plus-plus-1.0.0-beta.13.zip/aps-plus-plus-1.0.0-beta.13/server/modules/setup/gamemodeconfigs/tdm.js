module.exports = {
    MODE: "tdm",
    TEAMS: 4,
    ROOM_SETUP: ['overlay_tdm']
};