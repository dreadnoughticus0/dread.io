module.exports = {
    MODE: "tdm",
    TEAMS: 1,
    TILE_WIDTH: 200,
    TILE_HEIGHT: 200,
    ROOM_SETUP: ['map_nexus_trplnr']
}
