module.exports = {
    TEAMS: 2,
    TAG: true,
};